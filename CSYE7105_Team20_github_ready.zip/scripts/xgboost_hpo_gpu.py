#!/usr/bin/env python3
# XGBoost GPU Hyperparameter Optimization
# Fast GridSearchCV on GPU

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_absolute_error, r2_score
import time
import json
import os

print("="*80)
print("XGBOOST GPU HYPERPARAMETER OPTIMIZATION")
print("="*80)

# Check GPU
print(f"\nXGBoost version: {xgb.__version__}")
print(f"CUDA available: {xgb.build_info().get('USE_CUDA', False)}")
print(f"CUDA version: {xgb.build_info().get('CUDA_VERSION', 'N/A')}")

# Load data
print("\n[1/4] Loading data...")
df = pd.read_csv('data/processed/feature_engineered.csv', low_memory=False)
df.columns = df.columns.str.strip()

numeric_cols = ['LAND SQUARE FEET', 'GROSS SQUARE FEET', 'YEAR BUILT',
                'RESIDENTIAL UNITS', 'COMMERCIAL UNITS', 'TOTAL UNITS']
for col in numeric_cols:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')

df = df.dropna(subset=['SALE PRICE', 'SALE_YEAR'])
df['SALE DATE'] = pd.to_datetime(df['SALE DATE'], errors='coerce')

train_df = df[df['SALE_YEAR'] <= 2021].copy()
val_df = df[df['SALE_YEAR'] == 2022].copy()
test_df = df[df['SALE_YEAR'] == 2023].copy()

print(f"  Train: {len(train_df):,} | Val: {len(val_df):,} | Test: {len(test_df):,}")

# Encode
print("\n[2/4] Encoding features...")
excl = ['SALE DATE', 'ADDRESS', 'APARTMENT NUMBER', 'SALE PRICE',
        'BUILDING CLASS AT PRESENT', 'BUILDING CLASS AT TIME OF SALE',
        'TAX CLASS AT PRESENT', 'TAX CLASS AT TIME OF SALE']
feat_cols = [c for c in df.columns if c not in excl]

cats = ['BOROUGH', 'NEIGHBORHOOD', 'BUILDING CLASS CATEGORY',
        'ZIP CODE', 'BLOCK', 'LOT', 'EASE-MENT']

for col in [c for c in cats if c in feat_cols]:
    le = LabelEncoder()
    train_df[col] = le.fit_transform(train_df[col].astype(str))
    
    # Map val/test using training encoder, handle unseen categories
    class_map = {cls: i for i, cls in enumerate(le.classes_)}
    val_df[col] = val_df[col].astype(str).map(lambda x: class_map.get(x, 0))
    test_df[col] = test_df[col].astype(str).map(lambda x: class_map.get(x, 0))

X_train = train_df[feat_cols].values
y_train = train_df['SALE PRICE'].values
X_test = test_df[feat_cols].values
y_test = test_df['SALE PRICE'].values

X_train = np.nan_to_num(X_train, nan=0.0)
X_test = np.nan_to_num(X_test, nan=0.0)

print(f"  Shape: {X_train.shape}")

# Parameter grid
print("\n[3/4] GridSearchCV on GPU...")
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [5, 7, 9],
    'learning_rate': [0.01, 0.1, 0.2],
    'min_child_weight': [1, 3, 5]
}

print(f"  Parameter combinations: {3*3*3*3} = 81")
print(f"  Cross-validation folds: 5")
print(f"  Total model fits: 81 × 5 = 405")
print(f"  Using: 1 GPU (GridSearchCV runs sequentially)")
print()

# GridSearchCV on GPU
base_model = xgb.XGBRegressor(
    tree_method='hist',
    device='cuda:0',  # GPU
    random_state=42
)

t0 = time.time()

grid_search = GridSearchCV(
    estimator=base_model,
    param_grid=param_grid,
    cv=5,
    scoring='neg_mean_absolute_error',
    verbose=2,
    n_jobs=1  # GPU doesn't benefit from n_jobs
)

grid_search.fit(X_train, y_train)

gpu_time = time.time() - t0

print(f"\n✓ GridSearchCV Complete: {gpu_time:.1f}s ({gpu_time/60:.1f} min)")

# Best parameters
print("\n" + "="*80)
print("BEST PARAMETERS")
print("="*80)
best_params = grid_search.best_params_
for param, value in best_params.items():
    print(f"  {param}: {value}")

print(f"\nBest CV MAE: ${-grid_search.best_score_:,.2f}")

# Test on test set
print("\n[4/4] Testing best model...")
best_model = grid_search.best_estimator_
y_pred = best_model.predict(X_test)

mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"  Test MAE:  ${mae:,.2f}")
print(f"  Test R²:   {r2:.4f}")

# Save
os.makedirs('models', exist_ok=True)
best_model.save_model('models/xgboost_best_hpo_gpu.json')

os.makedirs('results/timings', exist_ok=True)
results = {
    'method': 'GridSearchCV GPU',
    'time_s': gpu_time,
    'best_params': best_params,
    'best_cv_mae': float(-grid_search.best_score_),
    'test_mae': float(mae),
    'test_r2': float(r2)
}

with open('results/timings/xgboost_hpo_gpu.json', 'w') as f:
    json.dump(results, f, indent=2)

print("\n" + "="*80)
print("✓ XGBOOST GPU HPO COMPLETE")
print("="*80)
print(f"Time: {gpu_time:.1f}s ({gpu_time/60:.1f} min)")
print(f"Best model saved: models/xgboost_best_hpo_gpu.json")
print(f"Results saved: results/timings/xgboost_hpo_gpu.json")
print("="*80)