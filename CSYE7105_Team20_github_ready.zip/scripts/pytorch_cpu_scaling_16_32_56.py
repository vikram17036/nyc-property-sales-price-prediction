#!/usr/bin/env python3
# PHASE 4: PyTorch CPU Scaling - Higher Process Counts
# Tests ONLY: 16, 32, 56 processes (already have 2 and 4)

import os
os.environ['MKL_THREADING_LAYER'] = 'GNU'
os.environ['MKL_SERVICE_FORCE_INTEL'] = '1'
os.environ['PYTHONUNBUFFERED'] = '1'

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler
from torch.distributed.fsdp import fully_shard
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import mean_absolute_error, r2_score
import time
import json
import sys

EPOCHS = 20  # Match previous runs (2 and 4 processes)
BATCH_SIZE = 2048
LR = 0.001
SEED = 42

class PropertyPriceNN(nn.Module):
    def __init__(self, input_size):
        super().__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 32)
        self.fc4 = nn.Linear(32, 1)
    
    def forward(self, x):
        return self.fc4(F.relu(self.fc3(F.relu(self.fc2(F.relu(self.fc1(x)))))))

def setup(rank, world_size):
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = '29500'
    dist.init_process_group("gloo", rank=rank, world_size=world_size)

def cleanup():
    try:
        dist.destroy_process_group()
    except:
        pass

def train_epoch(model, loader, opt, crit, sampler, epoch, rank):
    model.train()
    sampler.set_epoch(epoch)
    loss_sum, count = 0.0, 0
    
    for X, y in loader:
        opt.zero_grad()
        loss = crit(model(X), y)
        
        if torch.isnan(loss):
            print(f"[RANK {rank}] NaN at epoch {epoch+1}!", flush=True)
            return None
        
        loss.backward()
        opt.step()
        loss_sum += loss.item() * X.size(0)
        count += X.size(0)
    
    loss_t = torch.tensor(loss_sum)
    count_t = torch.tensor(count)
    dist.all_reduce(loss_t, op=dist.ReduceOp.SUM)
    dist.all_reduce(count_t, op=dist.ReduceOp.SUM)
    
    avg_loss = (loss_t / count_t).item()
    
    if rank == 0 and (epoch + 1) % 5 == 0:
        print(f"  Epoch {epoch+1}/{EPOCHS} - Loss: {avg_loss:.6f}", flush=True)
    
    return avg_loss

def ddp_worker(rank, world_size, X, y):
    try:
        setup(rank, world_size)
        
        if rank == 0:
            print(f"[DDP] Starting on {world_size} processes...", flush=True)
        
        ds = TensorDataset(X, y)
        sampler = DistributedSampler(ds, num_replicas=world_size, rank=rank, seed=SEED)
        loader = DataLoader(ds, batch_size=BATCH_SIZE, sampler=sampler, num_workers=0)
        
        model = DDP(PropertyPriceNN(X.shape[1]))
        opt = optim.Adam(model.parameters(), lr=LR)
        crit = nn.MSELoss()
        
        for e in range(EPOCHS):
            result = train_epoch(model, loader, opt, crit, sampler, e, rank)
            if result is None:
                if rank == 0:
                    print("[DDP] Training failed!", flush=True)
                cleanup()
                return
        
        if rank == 0:
            print("[DDP] Complete!", flush=True)
        
        cleanup()
        
    except Exception as ex:
        print(f"[RANK {rank}] ERROR: {ex}", flush=True)
        cleanup()
        raise

def fsdp2_worker(rank, world_size, X, y):
    try:
        setup(rank, world_size)
        
        if rank == 0:
            print(f"[FSDP2] Starting on {world_size} processes...", flush=True)
        
        ds = TensorDataset(X, y)
        sampler = DistributedSampler(ds, num_replicas=world_size, rank=rank, seed=SEED)
        loader = DataLoader(ds, batch_size=BATCH_SIZE, sampler=sampler, num_workers=0)
        
        model = PropertyPriceNN(X.shape[1])
        model.fc1 = fully_shard(model.fc1)
        model.fc2 = fully_shard(model.fc2)
        model.fc3 = fully_shard(model.fc3)
        model.fc4 = fully_shard(model.fc4)
        model = fully_shard(model)
        
        opt = optim.Adam(model.parameters(), lr=LR)
        crit = nn.MSELoss()
        
        for e in range(EPOCHS):
            result = train_epoch(model, loader, opt, crit, sampler, e, rank)
            if result is None:
                if rank == 0:
                    print("[FSDP2] Training failed!", flush=True)
                cleanup()
                return
        
        if rank == 0:
            print("[FSDP2] Complete!", flush=True)
        
        cleanup()
        
    except Exception as ex:
        print(f"[RANK {rank}] ERROR: {ex}", flush=True)
        cleanup()
        raise

if __name__ == '__main__':
    print("="*80)
    print("PHASE 4: PyTorch CPU Scaling (16, 32, 56 processes)")
    print("="*80)
    print("Note: Already have 2 and 4 process results from previous run")
    print("="*80)
    
    torch.manual_seed(SEED)
    np.random.seed(SEED)
    
    # ========== DATA LOADING ==========
    print("\n[1/3] Loading and preparing data...")
    df = pd.read_csv('data/processed/feature_engineered.csv', low_memory=False)
    df.columns = df.columns.str.strip()
    
    numeric_cols = ['LAND SQUARE FEET', 'GROSS SQUARE FEET', 'YEAR BUILT',
                    'RESIDENTIAL UNITS', 'COMMERCIAL UNITS', 'TOTAL UNITS']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    df = df.dropna(subset=['SALE PRICE', 'SALE_YEAR'])
    df['SALE DATE'] = pd.to_datetime(df['SALE DATE'], errors='coerce')
    
    train_df = df[df['SALE_YEAR'] <= 2021].copy()
    test_df = df[df['SALE_YEAR'] == 2023].copy()
    print(f"  Train: {len(train_df):,} | Test: {len(test_df):,}")
    
    print("\n[2/3] Encoding and normalizing...")
    excl = ['SALE DATE', 'ADDRESS', 'APARTMENT NUMBER', 'SALE PRICE',
            'BUILDING CLASS AT PRESENT', 'BUILDING CLASS AT TIME OF SALE',
            'TAX CLASS AT PRESENT', 'TAX CLASS AT TIME OF SALE']
    feat_cols = [c for c in df.columns if c not in excl]
    
    cats = ['BOROUGH', 'NEIGHBORHOOD', 'BUILDING CLASS CATEGORY',
            'ZIP CODE', 'BLOCK', 'LOT', 'EASE-MENT']
    
    for col in [c for c in cats if c in feat_cols]:
        le = LabelEncoder()
        train_df[col] = le.fit_transform(train_df[col].astype(str))
        cm = {cls: i for i, cls in enumerate(le.classes_)}
        test_df[col] = test_df[col].astype(str).map(lambda x: cm.get(x, 0))
    
    X_tr = train_df[feat_cols].values.astype(np.float32)
    y_tr = train_df['SALE PRICE'].values.astype(np.float32).reshape(-1, 1)
    X_te = test_df[feat_cols].values.astype(np.float32)
    y_te = test_df['SALE PRICE'].values
    
    X_tr = np.nan_to_num(X_tr, nan=0.0)
    X_te = np.nan_to_num(X_te, nan=0.0)
    
    sc_X = StandardScaler()
    X_tr = sc_X.fit_transform(X_tr)
    X_te = sc_X.transform(X_te)
    
    sc_y = StandardScaler()
    y_tr = sc_y.fit_transform(y_tr)
    
    print(f"  Shape: {X_tr.shape}")
    print(f"  Done")
    
    X_tr_t = torch.FloatTensor(X_tr)
    y_tr_t = torch.FloatTensor(y_tr)
    X_te_t = torch.FloatTensor(X_te)
    
    # ========== SCALING TESTS ==========
    print("\n[3/3] CPU Scaling Tests (20 epochs each to match previous runs)...")
    print("="*80)
    
    all_results = {}
    process_counts = [16, 32, 56]
    
    # DDP TESTS
    for n_proc in process_counts:
        print(f"\n>>> DDP with {n_proc} processes")
        print("-"*80)
        
        t0 = time.time()
        mp.spawn(ddp_worker, args=(n_proc, X_tr_t, y_tr_t), nprocs=n_proc, join=True)
        ddp_time = time.time() - t0
        
        all_results[f'ddp_{n_proc}'] = {'time_s': ddp_time}
        print(f"✓ DDP {n_proc}: {ddp_time:.1f}s ({ddp_time/60:.1f} min)\n")
    
    # FSDP2 TESTS
    for n_proc in process_counts:
        print(f"\n>>> FSDP2 with {n_proc} processes")
        print("-"*80)
        
        t0 = time.time()
        mp.spawn(fsdp2_worker, args=(n_proc, X_tr_t, y_tr_t), nprocs=n_proc, join=True)
        fsdp2_time = time.time() - t0
        
        all_results[f'fsdp2_{n_proc}'] = {'time_s': fsdp2_time}
        print(f"✓ FSDP2 {n_proc}: {fsdp2_time:.1f}s ({fsdp2_time/60:.1f} min)\n")
    
    # ========== SAVE RESULTS ==========
    os.makedirs('results/timings', exist_ok=True)
    with open('results/timings/phase4_cpu_additional.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    # ========== SUMMARY ==========
    print("\n" + "="*80)
    print("✓✓✓ PHASE 4 ADDITIONAL CPU TESTS COMPLETE ✓✓✓")
    print("="*80)
    print("\nDDP Results:")
    for n_proc in process_counts:
        t = all_results[f'ddp_{n_proc}']['time_s']
        print(f"  {n_proc:2d} processes: {t:6.1f}s ({t/60:.1f} min)")
    
    print("\nFSDP2 Results:")
    for n_proc in process_counts:
        t = all_results[f'fsdp2_{n_proc}']['time_s']
        print(f"  {n_proc:2d} processes: {t:6.1f}s ({t/60:.1f} min)")
    
    print("\nCombine with previous results (2 and 4 processes) for complete analysis")
    print("="*80)