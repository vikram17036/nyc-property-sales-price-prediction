#!/usr/bin/env python3
# PHASE 5: PyTorch GPU Training - Complete Scaling Test
# Tests: 1, 2, 4 GPUs for both DDP and FSDP2

import os
os.environ['PYTHONUNBUFFERED'] = '1'

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler
from torch.distributed._composable.fsdp import fully_shard
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import mean_absolute_error, r2_score
import time
import json
import sys

EPOCHS = 10
BATCH_SIZE = 2048
LR = 0.001
SEED = 42

class PropertyPriceNN(nn.Module):
    def __init__(self, input_size):
        super().__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 32)
        self.fc4 = nn.Linear(32, 1)
    
    def forward(self, x):
        return self.fc4(F.relu(self.fc3(F.relu(self.fc2(F.relu(self.fc1(x)))))))

def setup(rank, world_size):
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = '29600'
    dist.init_process_group("nccl", rank=rank, world_size=world_size)
    torch.cuda.set_device(rank)

def cleanup():
    try:
        dist.destroy_process_group()
    except:
        pass

def train_epoch(model, loader, opt, crit, sampler, epoch, rank, device, world_size):
    model.train()
    if sampler:
        sampler.set_epoch(epoch)
    
    loss_sum, count = 0.0, 0
    
    for X, y in loader:
        X, y = X.to(device), y.to(device)
        
        opt.zero_grad()
        loss = crit(model(X), y)
        
        if torch.isnan(loss):
            print(f"[RANK {rank}] NaN at epoch {epoch+1}!", flush=True)
            return None
        
        loss.backward()
        opt.step()
        loss_sum += loss.item() * X.size(0)
        count += X.size(0)
    
    if world_size > 1:
        loss_t = torch.tensor(loss_sum).to(device)
        count_t = torch.tensor(count).to(device)
        dist.all_reduce(loss_t, op=dist.ReduceOp.SUM)
        dist.all_reduce(count_t, op=dist.ReduceOp.SUM)
        avg_loss = (loss_t / count_t).item()
    else:
        avg_loss = loss_sum / count
    
    if rank == 0 and (epoch + 1) % 5 == 0:
        print(f"  Epoch {epoch+1}/{EPOCHS} - Loss: {avg_loss:.6f}", flush=True)
    
    return avg_loss

def ddp_worker(rank, world_size, X, y):
    try:
        setup(rank, world_size)
        device = torch.device(f'cuda:{rank}')
        
        if rank == 0:
            print(f"[DDP] Starting on {world_size} GPU(s)...", flush=True)
        
        ds = TensorDataset(X, y)
        sampler = DistributedSampler(ds, num_replicas=world_size, rank=rank, seed=SEED)
        loader = DataLoader(ds, batch_size=BATCH_SIZE, sampler=sampler, num_workers=0, pin_memory=True)
        
        model = PropertyPriceNN(X.shape[1]).to(device)
        model = DDP(model, device_ids=[rank])
        
        opt = optim.Adam(model.parameters(), lr=LR)
        crit = nn.MSELoss()
        
        for e in range(EPOCHS):
            result = train_epoch(model, loader, opt, crit, sampler, e, rank, device, world_size)
            if result is None:
                if rank == 0:
                    print("[DDP] Training failed!", flush=True)
                cleanup()
                return
        
        if rank == 0:
            print("[DDP] Complete!", flush=True)
        
        cleanup()
        
    except Exception as ex:
        print(f"[RANK {rank}] ERROR: {ex}", flush=True)
        import traceback
        traceback.print_exc()
        cleanup()
        raise

def fsdp2_worker(rank, world_size, X, y):
    try:
        setup(rank, world_size)
        device = torch.device(f'cuda:{rank}')
        
        if rank == 0:
            print(f"[FSDP2] Starting on {world_size} GPU(s)...", flush=True)
        
        ds = TensorDataset(X, y)
        sampler = DistributedSampler(ds, num_replicas=world_size, rank=rank, seed=SEED)
        loader = DataLoader(ds, batch_size=BATCH_SIZE, sampler=sampler, num_workers=0, pin_memory=True)
        
        model = PropertyPriceNN(X.shape[1]).to(device)
        
        # FSDP2: Apply fully_shard bottom-up
        model.fc1 = fully_shard(model.fc1)
        model.fc2 = fully_shard(model.fc2)
        model.fc3 = fully_shard(model.fc3)
        model.fc4 = fully_shard(model.fc4)
        model = fully_shard(model)
        
        opt = optim.Adam(model.parameters(), lr=LR)
        crit = nn.MSELoss()
        
        for e in range(EPOCHS):
            result = train_epoch(model, loader, opt, crit, sampler, e, rank, device, world_size)
            if result is None:
                if rank == 0:
                    print("[FSDP2] Training failed!", flush=True)
                cleanup()
                return
        
        if rank == 0:
            print("[FSDP2] Complete!", flush=True)
        
        cleanup()
        
    except Exception as ex:
        print(f"[RANK {rank}] ERROR: {ex}", flush=True)
        import traceback
        traceback.print_exc()
        cleanup()
        raise

if __name__ == '__main__':
    print("="*80)
    print("PHASE 5: PyTorch GPU Scaling Test (1, 2, 4 GPUs)")
    print("="*80)
    
    print(f"\nPyTorch: {torch.__version__}")
    print(f"CUDA: {torch.cuda.is_available()}")
    print(f"GPUs available: {torch.cuda.device_count()}")
    for i in range(torch.cuda.device_count()):
        print(f"  GPU {i}: {torch.cuda.get_device_name(i)}")
    
    torch.manual_seed(SEED)
    np.random.seed(SEED)
    
    # ========== DATA LOADING ==========
    print("\n[1/4] Loading data...")
    df = pd.read_csv('data/processed/feature_engineered.csv', low_memory=False)
    df.columns = df.columns.str.strip()
    
    numeric_cols = ['LAND SQUARE FEET', 'GROSS SQUARE FEET', 'YEAR BUILT',
                    'RESIDENTIAL UNITS', 'COMMERCIAL UNITS', 'TOTAL UNITS']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    df = df.dropna(subset=['SALE PRICE', 'SALE_YEAR'])
    df['SALE DATE'] = pd.to_datetime(df['SALE DATE'], errors='coerce')
    
    train_df = df[df['SALE_YEAR'] <= 2021].copy()
    test_df = df[df['SALE_YEAR'] == 2023].copy()
    print(f"  Train: {len(train_df):,} | Test: {len(test_df):,}")
    
    print("\n[2/4] Encoding features...")
    excl = ['SALE DATE', 'ADDRESS', 'APARTMENT NUMBER', 'SALE PRICE',
            'BUILDING CLASS AT PRESENT', 'BUILDING CLASS AT TIME OF SALE',
            'TAX CLASS AT PRESENT', 'TAX CLASS AT TIME OF SALE']
    feat_cols = [c for c in df.columns if c not in excl]
    
    cats = ['BOROUGH', 'NEIGHBORHOOD', 'BUILDING CLASS CATEGORY',
            'ZIP CODE', 'BLOCK', 'LOT', 'EASE-MENT']
    
    for col in [c for c in cats if c in feat_cols]:
        le = LabelEncoder()
        train_df[col] = le.fit_transform(train_df[col].astype(str))
        cm = {cls: i for i, cls in enumerate(le.classes_)}
        test_df[col] = test_df[col].astype(str).map(lambda x: cm.get(x, 0))
    
    X_tr = train_df[feat_cols].values.astype(np.float32)
    y_tr = train_df['SALE PRICE'].values.astype(np.float32).reshape(-1, 1)
    X_te = test_df[feat_cols].values.astype(np.float32)
    y_te = test_df['SALE PRICE'].values
    
    X_tr = np.nan_to_num(X_tr, nan=0.0)
    X_te = np.nan_to_num(X_te, nan=0.0)
    
    print(f"  Shape: {X_tr.shape}")
    
    print("\n[3/4] Normalizing...")
    sc_X = StandardScaler()
    X_tr = sc_X.fit_transform(X_tr)
    X_te = sc_X.transform(X_te)
    
    sc_y = StandardScaler()
    y_tr = sc_y.fit_transform(y_tr)
    print(f"  Done")
    
    X_tr_t = torch.FloatTensor(X_tr)
    y_tr_t = torch.FloatTensor(y_tr)
    X_te_t = torch.FloatTensor(X_te)
    
    # ========== SINGLE GPU BASELINE ==========
    print("\n[4/4] GPU Training Tests...")
    print("="*80)
    
    all_results = {}
    
    print("\n>>> TEST 1: Single GPU Baseline")
    print("-"*80)
    device = torch.device('cuda:0')
    model = PropertyPriceNN(X_tr.shape[1]).to(device)
    loader = DataLoader(TensorDataset(X_tr_t, y_tr_t), batch_size=BATCH_SIZE, shuffle=True)
    opt = optim.Adam(model.parameters(), lr=LR)
    crit = nn.MSELoss()
    
    t0 = time.time()
    for e in range(EPOCHS):
        model.train()
        for X, y in loader:
            X, y = X.to(device), y.to(device)
            opt.zero_grad()
            crit(model(X), y).backward()
            opt.step()
        if (e + 1) % 5 == 0:
            print(f"  Epoch {e+1}/{EPOCHS}")
    
    single_time = time.time() - t0
    
    model.eval()
    with torch.no_grad():
        y_pred_norm = model(X_te_t.to(device)).cpu().numpy()
    y_pred = sc_y.inverse_transform(y_pred_norm).flatten()
    mae = mean_absolute_error(y_te, y_pred)
    r2 = r2_score(y_te, y_pred)
    
    all_results['single_gpu'] = {'time_s': single_time, 'mae': float(mae), 'r2': float(r2)}
    print(f"✓ Single GPU: {single_time:.1f}s - MAE=${mae:,.0f}, R²={r2:.4f}\n")
    
    # ========== DDP TESTS ==========
    for n_gpus in [2, 4]:
        print(f">>> TEST: DDP with {n_gpus} GPUs")
        print("-"*80)
        
        t0 = time.time()
        mp.spawn(ddp_worker, args=(n_gpus, X_tr_t, y_tr_t), nprocs=n_gpus, join=True)
        ddp_time = time.time() - t0
        
        speedup = single_time / ddp_time
        efficiency = (speedup / n_gpus) * 100
        
        all_results[f'ddp_{n_gpus}gpu'] = {
            'time_s': ddp_time,
            'speedup': speedup,
            'efficiency': efficiency
        }
        print(f"✓ DDP {n_gpus} GPUs: {ddp_time:.1f}s - Speedup: {speedup:.2f}x, Efficiency: {efficiency:.1f}%\n")
    
    # ========== FSDP2 TESTS ==========
    for n_gpus in [2, 4]:
        print(f">>> TEST: FSDP2 with {n_gpus} GPUs")
        print("-"*80)
        
        t0 = time.time()
        mp.spawn(fsdp2_worker, args=(n_gpus, X_tr_t, y_tr_t), nprocs=n_gpus, join=True)
        fsdp2_time = time.time() - t0
        
        speedup = single_time / fsdp2_time
        efficiency = (speedup / n_gpus) * 100
        
        all_results[f'fsdp2_{n_gpus}gpu'] = {
            'time_s': fsdp2_time,
            'speedup': speedup,
            'efficiency': efficiency
        }
        print(f"✓ FSDP2 {n_gpus} GPUs: {fsdp2_time:.1f}s - Speedup: {speedup:.2f}x, Efficiency: {efficiency:.1f}%\n")
    
    # ========== FINAL EVALUATION ==========
    print("="*80)
    print("FINAL EVALUATION")
    print("="*80)
    
    device = torch.device('cuda:0')
    loader = DataLoader(TensorDataset(X_tr_t, y_tr_t), batch_size=BATCH_SIZE, shuffle=True)
    
    for name in ['ddp_2gpu', 'ddp_4gpu', 'fsdp2_2gpu', 'fsdp2_4gpu']:
        print(f"\nTraining final {name.upper()} model for accuracy...")
        model = PropertyPriceNN(X_tr.shape[1]).to(device)
        opt = optim.Adam(model.parameters(), lr=LR)
        crit = nn.MSELoss()
        
        for e in range(EPOCHS):
            model.train()
            for X, y in loader:
                X, y = X.to(device), y.to(device)
                opt.zero_grad()
                crit(model(X), y).backward()
                opt.step()
        
        model.eval()
        with torch.no_grad():
            y_pred_norm = model(X_te_t.to(device)).cpu().numpy()
        
        y_pred = sc_y.inverse_transform(y_pred_norm).flatten()
        mae = mean_absolute_error(y_te, y_pred)
        r2 = r2_score(y_te, y_pred)
        
        os.makedirs('models', exist_ok=True)
        torch.save(model.state_dict(), f'models/pytorch_{name}.pth')
        
        all_results[name]['mae'] = float(mae)
        all_results[name]['r2'] = float(r2)
        print(f"  ✓ MAE=${mae:,.0f}, R²={r2:.4f}")
    
    # ========== SAVE RESULTS ==========
    os.makedirs('results/timings', exist_ok=True)
    with open('results/timings/phase5_gpu_complete.json', 'w') as f:
        json.dump(all_results, f, indent=2)
    
    # ========== SUMMARY ==========
    print("\n" + "="*80)
    print("✓✓✓ PHASE 5 GPU COMPLETE - FULL SCALING TEST ✓✓✓")
    print("="*80)
    print(f"\nSingle GPU Baseline: {single_time:.1f}s")
    print(f"\nDDP Scaling:")
    print(f"  2 GPUs: {all_results['ddp_2gpu']['time_s']:.1f}s - {all_results['ddp_2gpu']['speedup']:.2f}x speedup ({all_results['ddp_2gpu']['efficiency']:.1f}% eff)")
    print(f"  4 GPUs: {all_results['ddp_4gpu']['time_s']:.1f}s - {all_results['ddp_4gpu']['speedup']:.2f}x speedup ({all_results['ddp_4gpu']['efficiency']:.1f}% eff)")
    print(f"\nFSDP2 Scaling:")
    print(f"  2 GPUs: {all_results['fsdp2_2gpu']['time_s']:.1f}s - {all_results['fsdp2_2gpu']['speedup']:.2f}x speedup ({all_results['fsdp2_2gpu']['efficiency']:.1f}% eff)")
    print(f"  4 GPUs: {all_results['fsdp2_4gpu']['time_s']:.1f}s - {all_results['fsdp2_4gpu']['speedup']:.2f}x speedup ({all_results['fsdp2_4gpu']['efficiency']:.1f}% eff)")
    print("\n" + "="*80)